// Optional interactivity can be added here
console.log("Welcome to Sravya Challa's Portfolio!");